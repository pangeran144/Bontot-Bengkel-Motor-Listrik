import { createBrowserRouter } from "react-router";
import Root from "./pages/Root";
import Home from "./pages/Home";
import Booking from "./pages/Booking";
import Spareparts from "./pages/Spareparts";
import Contact from "./pages/Contact";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import DashboardLayout from "./pages/dashboard/DashboardLayout";
import DashboardHome from "./pages/dashboard/DashboardHome";
import MyBookings from "./pages/dashboard/MyBookings";
import BookingDetail from "./pages/dashboard/BookingDetail";
import PurchaseHistory from "./pages/dashboard/PurchaseHistory";
import MyAddresses from "./pages/dashboard/MyAddresses";
import Profile from "./pages/dashboard/Profile";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "booking", Component: Booking },
      { path: "spareparts", Component: Spareparts },
      { path: "contact", Component: Contact },
    ],
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/register",
    Component: Register,
  },
  {
    path: "/dashboard",
    Component: DashboardLayout,
    children: [
      { index: true, Component: DashboardHome },
      { path: "bookings", Component: MyBookings },
      { path: "bookings/:id", Component: BookingDetail },
      { path: "purchases", Component: PurchaseHistory },
      { path: "addresses", Component: MyAddresses },
      { path: "profile", Component: Profile },
    ],
  },
]);
