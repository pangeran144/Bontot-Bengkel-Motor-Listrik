import { Link } from "react-router";
import { motion } from "motion/react";
import { Battery, Wrench, Zap, CheckCircle, MapPin, Award } from "lucide-react";

export default function Home() {
  const services = [
    {
      icon: Battery,
      title: "Servis Baterai",
      description: "Pengecekan dan perawatan baterai motor listrik untuk performa optimal",
    },
    {
      icon: Wrench,
      title: "Perbaikan Rem",
      description: "Servis rem profesional untuk keamanan berkendara maksimal",
    },
    {
      icon: Zap,
      title: "Cek Kelistrikan",
      description: "Diagnosa dan perbaikan sistem kelistrikan motor listrik",
    },
    {
      icon: CheckCircle,
      title: "General Service",
      description: "Perawatan menyeluruh untuk performa motor yang prima",
    },
  ];

  const spareparts = [
    {
      name: "Baterai Lithium 60V",
      price: "Rp 4.500.000",
      image: "https://images.unsplash.com/photo-1582719182141-86f32a7c2acc?w=400&h=300&fit=crop",
    },
    {
      name: "Controller Motor",
      price: "Rp 1.200.000",
      image: "https://images.unsplash.com/photo-1589802861088-ee21123ec577?w=400&h=300&fit=crop",
    },
    {
      name: "Charger Fast Charging",
      price: "Rp 850.000",
      image: "https://images.unsplash.com/photo-1636761358770-009ce3957519?w=400&h=300&fit=crop",
    },
    {
      name: "Brake Pad Set",
      price: "Rp 250.000",
      image: "https://images.unsplash.com/photo-1636761358783-209512dccd98?w=400&h=300&fit=crop",
    },
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center py-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                Servis Motor Listrik Profesional
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Layanan Bengkel & Home Service Jabodetabek
              </p>

              <div className="flex flex-wrap gap-4 mb-12">
                <Link
                  to="/booking"
                  className="bg-[#22c55e] text-white px-8 py-4 rounded-lg hover:bg-[#16a34a] transition-all hover:scale-105"
                >
                  Booking Sekarang
                </Link>
                <a
                  href="#layanan"
                  className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-lg hover:border-[#22c55e] hover:text-[#22c55e] transition-all"
                >
                  Lihat Layanan
                </a>
              </div>

              <div className="grid sm:grid-cols-3 gap-6">
                <div className="flex items-start gap-3">
                  <Award className="w-6 h-6 text-[#22c55e] flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-semibold text-gray-900">Teknisi Berpengalaman</p>
                    <p className="text-sm text-gray-600">Certified & Profesional</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="w-6 h-6 text-[#22c55e] flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-semibold text-gray-900">Home Service Jabodetabek</p>
                    <p className="text-sm text-gray-600">Kami datang ke lokasi Anda</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-[#22c55e] flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-semibold text-gray-900">Sparepart Original</p>
                    <p className="text-sm text-gray-600">Garansi resmi</p>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <img
                src="https://images.unsplash.com/photo-1582719182141-86f32a7c2acc?w=800&h=600&fit=crop"
                alt="Electric Motorcycle"
                className="rounded-2xl shadow-2xl w-full"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
                <p className="text-4xl font-bold text-[#22c55e]">500+</p>
                <p className="text-gray-600">Motor Terservis</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="layanan" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Layanan Kami</h2>
            <p className="text-xl text-gray-600">Solusi lengkap untuk motor listrik Anda</p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all cursor-pointer"
              >
                <div className="w-14 h-14 bg-[#22c55e]/10 rounded-xl flex items-center justify-center mb-6">
                  <service.icon className="w-7 h-7 text-[#22c55e]" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <Link
                  to="/booking"
                  className="text-[#22c55e] font-semibold hover:text-[#16a34a] transition-colors inline-flex items-center gap-2"
                >
                  Lihat Detail
                  <span>→</span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Spareparts Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Sparepart Terlaris</h2>
            <p className="text-xl text-gray-600">Sparepart original dengan garansi resmi</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {spareparts.map((product, index) => (
              <motion.div
                key={product.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all overflow-hidden cursor-pointer"
              >
                <div className="aspect-[4/3] overflow-hidden bg-gray-100">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <p className="text-2xl font-bold text-[#22c55e] mb-4">{product.price}</p>
                  <Link
                    to="/spareparts"
                    className="w-full block text-center border-2 border-[#22c55e] text-[#22c55e] py-2.5 rounded-lg hover:bg-[#22c55e] hover:text-white transition-colors"
                  >
                    Lihat Detail
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="text-center">
            <Link
              to="/spareparts"
              className="inline-block bg-gray-900 text-white px-8 py-4 rounded-lg hover:bg-gray-800 transition-colors"
            >
              Lihat Semua Sparepart
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
