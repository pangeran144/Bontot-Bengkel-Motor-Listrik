import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { motion } from "motion/react";
import { User, Phone, Mail, Lock, Zap } from "lucide-react";

export default function Register() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    password: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock registration - in real app, would call API
    localStorage.setItem("user", JSON.stringify({ name: formData.name, email: formData.email }));
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Side - Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-lg p-8 lg:p-12"
          >
            <div className="mb-8">
              <Link to="/" className="flex items-center gap-2 mb-8">
                <div className="w-10 h-10 bg-[#22c55e] rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <span className="font-semibold text-xl text-gray-900">VoltService</span>
              </Link>

              <h1 className="text-3xl font-bold text-gray-900 mb-2">Daftar Akun</h1>
              <p className="text-gray-600">Buat akun untuk mulai menggunakan layanan kami</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2">Nama Lengkap</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Masukkan nama lengkap"
                    className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Nomor HP</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="08xx xxxx xxxx"
                    className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="email@example.com"
                    className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Minimal 8 karakter"
                    className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    required
                    minLength={8}
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#22c55e] text-white py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
              >
                Daftar
              </button>

              <div className="text-center">
                <p className="text-gray-600">
                  Sudah punya akun?{" "}
                  <Link to="/login" className="text-[#22c55e] hover:text-[#16a34a] font-semibold">
                    Login
                  </Link>
                </p>
              </div>
            </form>
          </motion.div>

          {/* Right Side - Illustration */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="hidden lg:block"
          >
            <div className="bg-gradient-to-br from-[#22c55e]/10 to-[#16a34a]/10 rounded-2xl p-12 h-full flex flex-col justify-center">
              <img
                src="https://images.unsplash.com/photo-1636761358783-209512dccd98?w=600&h=600&fit=crop"
                alt="Electric Motorcycle"
                className="rounded-xl mb-8 shadow-lg"
              />
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Bergabung dengan VoltService Sekarang
              </h2>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full" />
                  Gratis tanpa biaya pendaftaran
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full" />
                  Promo dan diskon eksklusif member
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full" />
                  Akses prioritas booking service
                </li>
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
