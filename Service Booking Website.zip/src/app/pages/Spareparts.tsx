import { motion } from "motion/react";
import { Link } from "react-router";
import { ShoppingCart } from "lucide-react";

export default function Spareparts() {
  const products = [
    {
      name: "Baterai Lithium 60V 20Ah",
      price: "Rp 4.500.000",
      category: "Baterai",
      image: "https://images.unsplash.com/photo-1582719182141-86f32a7c2acc?w=400&h=300&fit=crop",
      stock: "Tersedia",
    },
    {
      name: "Controller Motor 1500W",
      price: "Rp 1.200.000",
      category: "Elektronik",
      image: "https://images.unsplash.com/photo-1589802861088-ee21123ec577?w=400&h=300&fit=crop",
      stock: "Tersedia",
    },
    {
      name: "Charger Fast Charging 10A",
      price: "Rp 850.000",
      category: "Aksesoris",
      image: "https://images.unsplash.com/photo-1636761358770-009ce3957519?w=400&h=300&fit=crop",
      stock: "Tersedia",
    },
    {
      name: "Brake Pad Set (Depan + Belakang)",
      price: "Rp 250.000",
      category: "Sparepart",
      image: "https://images.unsplash.com/photo-1636761358783-209512dccd98?w=400&h=300&fit=crop",
      stock: "Tersedia",
    },
    {
      name: "Ban Depan Tubeless 90/90-12",
      price: "Rp 320.000",
      category: "Sparepart",
      image: "https://images.unsplash.com/photo-1582719182141-86f32a7c2acc?w=400&h=300&fit=crop",
      stock: "Tersedia",
    },
    {
      name: "Ban Belakang Tubeless 100/90-12",
      price: "Rp 350.000",
      category: "Sparepart",
      image: "https://images.unsplash.com/photo-1589802861088-ee21123ec577?w=400&h=300&fit=crop",
      stock: "Tersedia",
    },
    {
      name: "Lampu LED Headlight",
      price: "Rp 180.000",
      category: "Elektronik",
      image: "https://images.unsplash.com/photo-1636761358770-009ce3957519?w=400&h=300&fit=crop",
      stock: "Pre-Order",
    },
    {
      name: "Spion Set Kanan-Kiri",
      price: "Rp 95.000",
      category: "Aksesoris",
      image: "https://images.unsplash.com/photo-1636761358783-209512dccd98?w=400&h=300&fit=crop",
      stock: "Tersedia",
    },
  ];

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Sparepart Motor Listrik</h1>
          <p className="text-xl text-gray-600">Sparepart original dengan garansi resmi</p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <motion.div
              key={product.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ y: -8 }}
              className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all overflow-hidden"
            >
              <div className="aspect-[4/3] overflow-hidden bg-gray-100 relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                />
                <span
                  className={`absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-semibold ${
                    product.stock === "Tersedia"
                      ? "bg-[#22c55e] text-white"
                      : "bg-yellow-400 text-gray-900"
                  }`}
                >
                  {product.stock}
                </span>
              </div>
              <div className="p-6">
                <p className="text-xs text-gray-500 mb-2">{product.category}</p>
                <h3 className="font-semibold text-gray-900 mb-2 min-h-[3rem]">{product.name}</h3>
                <p className="text-2xl font-bold text-[#22c55e] mb-4">{product.price}</p>
                <button className="w-full flex items-center justify-center gap-2 bg-[#22c55e] text-white py-2.5 rounded-lg hover:bg-[#16a34a] transition-colors">
                  <ShoppingCart className="w-4 h-4" />
                  Beli Sekarang
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 bg-white p-8 rounded-2xl shadow-sm">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Butuh Bantuan?</h2>
          <p className="text-gray-600 mb-6">
            Tidak menemukan sparepart yang Anda cari? Hubungi kami untuk konsultasi.
          </p>
          <Link
            to="/contact"
            className="inline-block bg-gray-900 text-white px-8 py-3 rounded-lg hover:bg-gray-800 transition-colors"
          >
            Hubungi Kami
          </Link>
        </div>
      </div>
    </div>
  );
}
