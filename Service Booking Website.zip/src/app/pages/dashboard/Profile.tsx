import { motion } from "motion/react";
import { useState, useEffect } from "react";
import { User, Mail, Phone, Edit2, Lock } from "lucide-react";

export default function Profile() {
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showPasswordForm, setShowPasswordForm] = useState(false);

  useEffect(() => {
    const userData = localStorage.getItem("user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Profil Saya</h1>
        <p className="text-gray-600">Kelola informasi profil Anda</p>
      </motion.div>

      {/* Profile Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl shadow-sm p-8 mb-6"
      >
        <div className="flex items-start justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 bg-gradient-to-br from-[#22c55e] to-[#16a34a] rounded-2xl flex items-center justify-center">
              <User className="w-10 h-10 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{user?.name || "User"}</h2>
              <p className="text-gray-600">{user?.email || "user@example.com"}</p>
            </div>
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-2 px-6 py-2.5 border-2 border-[#22c55e] text-[#22c55e] rounded-lg hover:bg-[#22c55e] hover:text-white transition-colors"
          >
            <Edit2 className="w-4 h-4" />
            {isEditing ? "Batal" : "Edit Profil"}
          </button>
        </div>

        {isEditing ? (
          <form className="space-y-6">
            <div>
              <label className="block text-gray-700 mb-2">Nama Lengkap</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  defaultValue={user?.name}
                  className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  defaultValue={user?.email}
                  className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Nomor HP</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="tel"
                  defaultValue="081234567890"
                  className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#22c55e] text-white py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
            >
              Simpan Perubahan
            </button>
          </form>
        ) : (
          <div className="space-y-6">
            <div>
              <label className="block text-sm text-gray-600 mb-1">Nama Lengkap</label>
              <p className="text-lg text-gray-900">{user?.name || "John Doe"}</p>
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-1">Email</label>
              <p className="text-lg text-gray-900">{user?.email || "john@example.com"}</p>
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-1">Nomor HP</label>
              <p className="text-lg text-gray-900">081234567890</p>
            </div>
          </div>
        )}
      </motion.div>

      {/* Change Password */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-2xl shadow-sm p-8"
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">Keamanan Akun</h2>
            <p className="text-gray-600">Kelola password dan keamanan akun Anda</p>
          </div>

          <button
            onClick={() => setShowPasswordForm(!showPasswordForm)}
            className="flex items-center gap-2 px-6 py-2.5 border-2 border-gray-300 text-gray-700 rounded-lg hover:border-[#22c55e] hover:text-[#22c55e] transition-colors"
          >
            <Lock className="w-4 h-4" />
            Ganti Password
          </button>
        </div>

        {showPasswordForm && (
          <form className="space-y-4 pt-4 border-t border-gray-200">
            <div>
              <label className="block text-gray-700 mb-2">Password Lama</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  placeholder="Masukkan password lama"
                  className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Password Baru</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  placeholder="Minimal 8 karakter"
                  className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Konfirmasi Password Baru</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  placeholder="Ketik ulang password baru"
                  className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="submit"
                className="flex-1 bg-[#22c55e] text-white py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
              >
                Simpan Password
              </button>
              <button
                type="button"
                onClick={() => setShowPasswordForm(false)}
                className="flex-1 border-2 border-gray-300 text-gray-700 py-3 rounded-lg hover:border-gray-400 transition-colors"
              >
                Batal
              </button>
            </div>
          </form>
        )}
      </motion.div>
    </div>
  );
}
