import { motion } from "motion/react";
import { Link } from "react-router";
import { Calendar, ShoppingBag, Clock, MapPin, Wrench, Battery, Lightbulb } from "lucide-react";
import { useEffect, useState } from "react";

export default function DashboardHome() {
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);

  useEffect(() => {
    const userData = localStorage.getItem("user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  const stats = [
    { label: "Total Booking", value: "12", icon: Calendar, color: "bg-blue-500" },
    { label: "Total Transaksi", value: "8", icon: ShoppingBag, color: "bg-green-500" },
    { label: "Booking Aktif", value: "2", icon: Clock, color: "bg-orange-500" },
  ];

  const recentBookings = [
    {
      id: 1,
      service: "Servis Baterai",
      motorcycle: "Gesits G1",
      date: "2026-04-15",
      location: "Home Service",
      status: "Diproses",
    },
    {
      id: 2,
      service: "General Check-up",
      motorcycle: "Viar Q1",
      date: "2026-04-10",
      location: "Bengkel",
      status: "Selesai",
    },
  ];

  const recommendations = [
    {
      icon: Battery,
      title: "Servis Baterai Rutin",
      description: "Motor Anda mungkin perlu servis baterai dalam waktu dekat",
      action: "Booking Sekarang",
    },
    {
      icon: Wrench,
      title: "Pengecekan Rem",
      description: "Sudah waktunya untuk cek kondisi rem motor listrik Anda",
      action: "Lihat Detail",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pending":
        return "bg-yellow-100 text-yellow-700";
      case "Diproses":
        return "bg-blue-100 text-blue-700";
      case "Selesai":
        return "bg-green-100 text-green-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Greeting */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Halo, {user?.name || "User"}! 👋
        </h1>
        <p className="text-gray-600">Selamat datang kembali di dashboard Anda</p>
      </motion.div>

      {/* Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 shadow-sm"
            >
              <div className="flex items-center gap-4">
                <div className={`w-14 h-14 ${stat.color} rounded-xl flex items-center justify-center`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <div>
                  <p className="text-gray-600 text-sm">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Recent Bookings */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-2xl shadow-sm p-6 mb-8"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Booking Terakhir</h2>
          <Link to="/dashboard/bookings" className="text-[#22c55e] hover:text-[#16a34a] font-semibold">
            Lihat Semua
          </Link>
        </div>

        <div className="space-y-4">
          {recentBookings.map((booking) => (
            <div
              key={booking.id}
              className="border border-gray-200 rounded-xl p-4 hover:border-[#22c55e] transition-colors"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">{booking.service}</h3>
                  <p className="text-sm text-gray-600">{booking.motorcycle}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(booking.status)}`}>
                  {booking.status}
                </span>
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>{booking.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>{booking.location}</span>
                </div>
              </div>

              <Link
                to={`/dashboard/bookings/${booking.id}`}
                className="mt-4 inline-block text-[#22c55e] hover:text-[#16a34a] font-semibold text-sm"
              >
                Lihat Detail →
              </Link>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Recommendations */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white rounded-2xl shadow-sm p-6"
      >
        <div className="flex items-center gap-2 mb-6">
          <Lightbulb className="w-6 h-6 text-[#22c55e]" />
          <h2 className="text-xl font-bold text-gray-900">Rekomendasi untuk Anda</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {recommendations.map((rec) => {
            const Icon = rec.icon;
            return (
              <div
                key={rec.title}
                className="border border-gray-200 rounded-xl p-6 hover:border-[#22c55e] transition-colors"
              >
                <div className="w-12 h-12 bg-[#22c55e]/10 rounded-xl flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-[#22c55e]" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{rec.title}</h3>
                <p className="text-sm text-gray-600 mb-4">{rec.description}</p>
                <Link
                  to="/booking"
                  className="inline-block text-[#22c55e] hover:text-[#16a34a] font-semibold text-sm"
                >
                  {rec.action} →
                </Link>
              </div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
