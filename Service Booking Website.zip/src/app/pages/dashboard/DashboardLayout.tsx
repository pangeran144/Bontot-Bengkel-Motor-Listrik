import { Outlet } from "react-router";
import DashboardSidebar from "../../components/dashboard/DashboardSidebar";

export default function DashboardLayout() {
  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardSidebar />

      <main className="lg:ml-64 pt-16 lg:pt-0 pb-20 lg:pb-0">
        <div className="p-4 lg:p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
