import { motion } from "motion/react";
import { useParams, useNavigate } from "react-router";
import { Calendar, MapPin, Clock, Phone, Mail, ArrowLeft, CheckCircle, Circle } from "lucide-react";

const mockBooking = {
  id: 1,
  service: "Servis Baterai",
  motorcycle: "Gesits G1",
  year: "2023",
  problem: "Baterai cepat habis dan motor sering mati mendadak saat digunakan",
  date: "2026-04-15",
  time: "10:00",
  location: "Home Service",
  address: "Jl. Kebon Jeruk No. 45, Jakarta Barat",
  city: "Jakarta",
  status: "Diproses",
  customerName: "John Doe",
  customerPhone: "081234567890",
  customerEmail: "john@example.com",
  createdAt: "2026-04-08",
};

const statusTimeline = [
  { label: "Booking Dibuat", status: "completed", date: "2026-04-08 14:30" },
  { label: "Booking Dikonfirmasi", status: "completed", date: "2026-04-08 15:00" },
  { label: "Teknisi Menuju Lokasi", status: "current", date: "2026-04-15 09:30" },
  { label: "Service Dimulai", status: "pending", date: "-" },
  { label: "Service Selesai", status: "pending", date: "-" },
];

export default function BookingDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pending":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "Diproses":
        return "bg-blue-100 text-blue-700 border-blue-200";
      case "Selesai":
        return "bg-green-100 text-green-700 border-green-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <button
          onClick={() => navigate("/dashboard/bookings")}
          className="flex items-center gap-2 text-gray-600 hover:text-[#22c55e] mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Kembali ke Booking Saya
        </button>

        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Detail Booking</h1>
            <p className="text-gray-600">Booking ID: #{id}</p>
          </div>
          <span className={`px-4 py-2 rounded-lg text-sm font-semibold border ${getStatusColor(mockBooking.status)}`}>
            {mockBooking.status}
          </span>
        </div>

        {/* Status Timeline */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Status Progress</h2>
          <div className="space-y-4">
            {statusTimeline.map((step, index) => (
              <div key={index} className="flex gap-4">
                <div className="flex flex-col items-center">
                  {step.status === "completed" ? (
                    <div className="w-10 h-10 bg-[#22c55e] rounded-full flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-white" />
                    </div>
                  ) : step.status === "current" ? (
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center animate-pulse">
                      <Circle className="w-6 h-6 text-white fill-white" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                      <Circle className="w-6 h-6 text-gray-400" />
                    </div>
                  )}
                  {index < statusTimeline.length - 1 && (
                    <div className={`w-0.5 h-12 ${step.status === "completed" ? "bg-[#22c55e]" : "bg-gray-200"}`} />
                  )}
                </div>
                <div className="flex-1 pb-8">
                  <h3 className={`font-semibold ${step.status === "pending" ? "text-gray-400" : "text-gray-900"}`}>
                    {step.label}
                  </h3>
                  <p className="text-sm text-gray-600">{step.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Booking Information */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Informasi Kendaraan</h2>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-600">Jenis Motor</p>
                <p className="font-medium text-gray-900">{mockBooking.motorcycle}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Tahun</p>
                <p className="font-medium text-gray-900">{mockBooking.year}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Jenis Service</p>
                <p className="font-medium text-gray-900">{mockBooking.service}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Jadwal</h2>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-[#22c55e]" />
                <div>
                  <p className="text-sm text-gray-600">Tanggal</p>
                  <p className="font-medium text-gray-900">{mockBooking.date}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-[#22c55e]" />
                <div>
                  <p className="text-sm text-gray-600">Waktu</p>
                  <p className="font-medium text-gray-900">{mockBooking.time}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Keluhan Motor</h2>
          <p className="text-gray-700">{mockBooking.problem}</p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Lokasi Service</h2>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-[#22c55e] mt-0.5" />
              <div>
                <p className="font-medium text-gray-900 mb-1">{mockBooking.location}</p>
                <p className="text-gray-700">{mockBooking.address}</p>
                <p className="text-sm text-gray-600">{mockBooking.city}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Data Pelanggan</h2>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-600">Nama</p>
              <p className="font-medium text-gray-900">{mockBooking.customerName}</p>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-[#22c55e]" />
              <div>
                <p className="text-sm text-gray-600">Nomor HP</p>
                <p className="font-medium text-gray-900">{mockBooking.customerPhone}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-[#22c55e]" />
              <div>
                <p className="text-sm text-gray-600">Email</p>
                <p className="font-medium text-gray-900">{mockBooking.customerEmail}</p>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
