import { motion } from "motion/react";
import { useState } from "react";
import { MapPin, Plus, Edit2, Trash2, Home, Building } from "lucide-react";

const mockAddresses = [
  {
    id: 1,
    label: "Rumah",
    name: "John Doe",
    phone: "081234567890",
    address: "Jl. Kebon Jeruk No. 45, RT 05/RW 03",
    city: "Jakarta Barat",
    postalCode: "11530",
    isDefault: true,
  },
  {
    id: 2,
    label: "Kantor",
    name: "John Doe",
    phone: "081234567890",
    address: "Jl. Sudirman No. 123, Lantai 5",
    city: "Jakarta Pusat",
    postalCode: "10220",
    isDefault: false,
  },
];

export default function MyAddresses() {
  const [addresses, setAddresses] = useState(mockAddresses);
  const [showForm, setShowForm] = useState(false);

  const handleDelete = (id: number) => {
    if (confirm("Apakah Anda yakin ingin menghapus alamat ini?")) {
      setAddresses(addresses.filter((addr) => addr.id !== id));
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Alamat Saya</h1>
            <p className="text-gray-600">Kelola alamat untuk home service</p>
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 bg-[#22c55e] text-white px-6 py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
          >
            <Plus className="w-5 h-5" />
            Tambah Alamat
          </button>
        </div>
      </motion.div>

      {/* Add Address Form */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="bg-white rounded-2xl shadow-sm p-6 mb-6"
        >
          <h2 className="text-xl font-bold text-gray-900 mb-6">Tambah Alamat Baru</h2>
          <form className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 mb-2">Label Alamat</label>
                <select className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none">
                  <option>Rumah</option>
                  <option>Kantor</option>
                  <option>Lainnya</option>
                </select>
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Nama Penerima</label>
                <input
                  type="text"
                  placeholder="Masukkan nama"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Nomor HP</label>
              <input
                type="tel"
                placeholder="08xx xxxx xxxx"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Alamat Lengkap</label>
              <textarea
                rows={3}
                placeholder="Jalan, RT/RW, Nomor rumah"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none resize-none"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 mb-2">Kota</label>
                <select className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none">
                  <option>Jakarta</option>
                  <option>Bogor</option>
                  <option>Depok</option>
                  <option>Tangerang</option>
                  <option>Bekasi</option>
                </select>
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Kode Pos</label>
                <input
                  type="text"
                  placeholder="12345"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input type="checkbox" id="default" className="w-4 h-4 text-[#22c55e] rounded" />
              <label htmlFor="default" className="text-gray-700">
                Jadikan alamat utama
              </label>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="submit"
                className="flex-1 bg-[#22c55e] text-white py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
              >
                Simpan Alamat
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="flex-1 border-2 border-gray-300 text-gray-700 py-3 rounded-lg hover:border-gray-400 transition-colors"
              >
                Batal
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Address List */}
      {addresses.length > 0 ? (
        <div className="space-y-4">
          {addresses.map((address, index) => (
            <motion.div
              key={address.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-sm p-6"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[#22c55e]/10 rounded-xl flex items-center justify-center">
                    {address.label === "Rumah" ? (
                      <Home className="w-6 h-6 text-[#22c55e]" />
                    ) : (
                      <Building className="w-6 h-6 text-[#22c55e]" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-gray-900">{address.label}</h3>
                      {address.isDefault && (
                        <span className="px-2 py-1 bg-[#22c55e]/10 text-[#22c55e] text-xs rounded-full">
                          Utama
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{address.name}</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button className="p-2 text-gray-600 hover:text-[#22c55e] transition-colors">
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(address.id)}
                    className="p-2 text-gray-600 hover:text-red-600 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="space-y-2 text-gray-700">
                <div className="flex items-start gap-2">
                  <MapPin className="w-5 h-5 text-[#22c55e] flex-shrink-0 mt-0.5" />
                  <div>
                    <p>{address.address}</p>
                    <p>
                      {address.city}, {address.postalCode}
                    </p>
                  </div>
                </div>
                <p className="text-sm text-gray-600 ml-7">{address.phone}</p>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <MapPin className="w-10 h-10 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Belum ada alamat tersimpan</h3>
          <p className="text-gray-600 mb-6">Tambahkan alamat untuk mempermudah home service</p>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center gap-2 bg-[#22c55e] text-white px-8 py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
          >
            <Plus className="w-5 h-5" />
            Tambah Alamat
          </button>
        </div>
      )}
    </div>
  );
}
