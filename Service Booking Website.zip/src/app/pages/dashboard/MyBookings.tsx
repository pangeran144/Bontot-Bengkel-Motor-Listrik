import { motion } from "motion/react";
import { Link } from "react-router";
import { Calendar, MapPin, Search } from "lucide-react";
import { useState } from "react";

const mockBookings = [
  {
    id: 1,
    service: "Servis Baterai",
    motorcycle: "Gesits G1",
    year: "2023",
    date: "2026-04-15",
    time: "10:00",
    location: "Home Service",
    address: "Jl. Kebon Jeruk No. 45, Jakarta Barat",
    status: "Diproses",
  },
  {
    id: 2,
    service: "General Check-up",
    motorcycle: "Viar Q1",
    year: "2022",
    date: "2026-04-10",
    time: "14:00",
    location: "Bengkel",
    address: "Bengkel VoltService",
    status: "Selesai",
  },
  {
    id: 3,
    service: "Servis Rem",
    motorcycle: "Uwinfly",
    year: "2024",
    date: "2026-04-20",
    time: "09:00",
    location: "Home Service",
    address: "Jl. Margonda Raya No. 88, Depok",
    status: "Pending",
  },
  {
    id: 4,
    service: "Cek Kelistrikan",
    motorcycle: "Gesits G1",
    year: "2023",
    date: "2026-03-25",
    time: "11:00",
    location: "Bengkel",
    address: "Bengkel VoltService",
    status: "Selesai",
  },
];

export default function MyBookings() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("Semua");

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pending":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "Diproses":
        return "bg-blue-100 text-blue-700 border-blue-200";
      case "Selesai":
        return "bg-green-100 text-green-700 border-green-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const filteredBookings = mockBookings.filter((booking) => {
    const matchesSearch =
      booking.service.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.motorcycle.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "Semua" || booking.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Booking Saya</h1>
        <p className="text-gray-600">Kelola semua booking service Anda</p>
      </motion.div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari service atau motor..."
              className="w-full pl-11 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
          >
            <option>Semua</option>
            <option>Pending</option>
            <option>Diproses</option>
            <option>Selesai</option>
          </select>
        </div>
      </div>

      {/* Bookings List */}
      {filteredBookings.length > 0 ? (
        <div className="grid gap-4">
          {filteredBookings.map((booking, index) => (
            <motion.div
              key={booking.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-sm p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">{booking.service}</h3>
                  <p className="text-gray-600">
                    {booking.motorcycle} {booking.year && `(${booking.year})`}
                  </p>
                </div>
                <span className={`px-4 py-2 rounded-lg text-sm font-semibold border ${getStatusColor(booking.status)}`}>
                  {booking.status}
                </span>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div className="flex items-center gap-3 text-gray-700">
                  <Calendar className="w-5 h-5 text-[#22c55e]" />
                  <div>
                    <p className="text-sm text-gray-600">Tanggal & Waktu</p>
                    <p className="font-medium">{booking.date} • {booking.time}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-gray-700">
                  <MapPin className="w-5 h-5 text-[#22c55e]" />
                  <div>
                    <p className="text-sm text-gray-600">{booking.location}</p>
                    <p className="font-medium">{booking.address}</p>
                  </div>
                </div>
              </div>

              <Link
                to={`/dashboard/bookings/${booking.id}`}
                className="inline-block px-6 py-2.5 border-2 border-[#22c55e] text-[#22c55e] rounded-lg hover:bg-[#22c55e] hover:text-white transition-colors"
              >
                Lihat Detail
              </Link>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="w-10 h-10 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Tidak ada booking ditemukan</h3>
          <p className="text-gray-600 mb-6">Coba ubah filter atau buat booking baru</p>
          <Link
            to="/booking"
            className="inline-block bg-[#22c55e] text-white px-8 py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
          >
            Booking Service Sekarang
          </Link>
        </div>
      )}
    </div>
  );
}
