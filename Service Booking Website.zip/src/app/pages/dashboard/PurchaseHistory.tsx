import { motion } from "motion/react";
import { ShoppingBag, Calendar, Package } from "lucide-react";

const mockPurchases = [
  {
    id: 1,
    date: "2026-04-05",
    items: [
      { name: "Baterai Lithium 60V", price: 4500000, quantity: 1 },
      { name: "Charger Fast Charging", price: 850000, quantity: 1 },
    ],
    total: 5350000,
    status: "Selesai",
  },
  {
    id: 2,
    date: "2026-03-20",
    items: [{ name: "Brake Pad Set", price: 250000, quantity: 2 }],
    total: 500000,
    status: "Selesai",
  },
  {
    id: 3,
    date: "2026-03-10",
    items: [
      { name: "Controller Motor", price: 1200000, quantity: 1 },
      { name: "Brake Pad Set", price: 250000, quantity: 1 },
    ],
    total: 1450000,
    status: "Selesai",
  },
];

export default function PurchaseHistory() {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const totalSpent = mockPurchases.reduce((sum, purchase) => sum + purchase.total, 0);

  return (
    <div className="max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Riwayat Pembelian</h1>
        <p className="text-gray-600">Lihat semua transaksi pembelian sparepart Anda</p>
      </motion.div>

      {/* Total Spent */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-gradient-to-br from-[#22c55e] to-[#16a34a] rounded-2xl shadow-lg p-8 mb-8 text-white"
      >
        <p className="text-white/80 mb-2">Total Pembelian</p>
        <p className="text-4xl font-bold">{formatCurrency(totalSpent)}</p>
        <p className="text-white/80 mt-2">{mockPurchases.length} transaksi</p>
      </motion.div>

      {/* Purchase List */}
      {mockPurchases.length > 0 ? (
        <div className="space-y-4">
          {mockPurchases.map((purchase, index) => (
            <motion.div
              key={purchase.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 + 0.2 }}
              className="bg-white rounded-2xl shadow-sm p-6"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-5 h-5 text-[#22c55e]" />
                    <p className="text-gray-600">{purchase.date}</p>
                  </div>
                  <p className="text-sm text-gray-600">Order ID: #{purchase.id}</p>
                </div>
                <span className="px-4 py-2 bg-green-100 text-green-700 rounded-lg text-sm font-semibold">
                  {purchase.status}
                </span>
              </div>

              <div className="border-t border-gray-200 pt-4 mb-4">
                <div className="space-y-3">
                  {purchase.items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                          <Package className="w-5 h-5 text-gray-600" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{item.name}</p>
                          <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                        </div>
                      </div>
                      <p className="font-semibold text-gray-900">{formatCurrency(item.price)}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4 flex items-center justify-between">
                <p className="text-lg font-semibold text-gray-900">Total</p>
                <p className="text-2xl font-bold text-[#22c55e]">{formatCurrency(purchase.total)}</p>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="w-10 h-10 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Belum ada riwayat pembelian</h3>
          <p className="text-gray-600 mb-6">Anda belum melakukan pembelian sparepart</p>
        </div>
      )}
    </div>
  );
}
