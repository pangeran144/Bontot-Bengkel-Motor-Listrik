import { motion } from "motion/react";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function Contact() {
  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Hubungi Kami</h1>
          <p className="text-xl text-gray-600">Kami siap membantu kebutuhan motor listrik Anda</p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            <div className="bg-white p-8 rounded-2xl shadow-sm">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Informasi Kontak</h2>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#22c55e]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-[#22c55e]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Alamat Bengkel</h3>
                    <p className="text-gray-600">
                      Jl. Raya Kampung Baru No. 123<br />
                      Jakarta Timur, DKI Jakarta 13450
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#22c55e]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-[#22c55e]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Telepon / WhatsApp</h3>
                    <p className="text-gray-600">+62 812-3456-7890</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#22c55e]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-[#22c55e]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Email</h3>
                    <p className="text-gray-600">info@voltservice.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#22c55e]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-[#22c55e]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Jam Operasional</h3>
                    <p className="text-gray-600">
                      Senin - Sabtu: 09:00 - 17:00<br />
                      Minggu: Tutup
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Area Layanan Home Service</h2>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full"></div>
                  Jakarta (Semua Area)
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full"></div>
                  Bogor
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full"></div>
                  Depok
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full"></div>
                  Tangerang & Tangerang Selatan
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full"></div>
                  Bekasi
                </li>
              </ul>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white p-8 rounded-2xl shadow-sm"
          >
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Kirim Pesan</h2>
            <form className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2">Nama</label>
                <input
                  type="text"
                  placeholder="Nama lengkap Anda"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  placeholder="email@example.com"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Nomor HP</label>
                <input
                  type="tel"
                  placeholder="08xx xxxx xxxx"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Pesan</label>
                <textarea
                  rows={5}
                  placeholder="Tulis pesan Anda di sini..."
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none resize-none"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-[#22c55e] text-white py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
              >
                Kirim Pesan
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
