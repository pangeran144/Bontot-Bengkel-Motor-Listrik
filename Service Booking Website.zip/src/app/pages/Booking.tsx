import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight, Check, Calendar, Clock, MapPin, Home as HomeIcon, Building } from "lucide-react";

interface BookingData {
  motorcycleType: string;
  motorcycleYear: string;
  serviceType: string[];
  problem: string;
  locationType: "bengkel" | "home" | "";
  address: string;
  city: string;
  date: string;
  time: string;
  name: string;
  phone: string;
  email: string;
}

export default function Booking() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<BookingData>({
    motorcycleType: "",
    motorcycleYear: "",
    serviceType: [],
    problem: "",
    locationType: "",
    address: "",
    city: "",
    date: "",
    time: "",
    name: "",
    phone: "",
    email: "",
  });

  const totalSteps = 7;

  const motorcycleTypes = ["Gesits", "Viar Q1", "Uwinfly", "Selis", "Volta", "Lainnya"];
  const serviceTypes = [
    { id: "battery", name: "Servis Baterai", description: "Pengecekan dan perawatan baterai" },
    { id: "brake", name: "Servis Rem", description: "Perbaikan sistem pengereman" },
    { id: "electrical", name: "Cek Kelistrikan", description: "Diagnosa sistem kelistrikan" },
    { id: "general", name: "General Check-up", description: "Pemeriksaan menyeluruh" },
  ];
  const cities = ["Jakarta", "Bogor", "Depok", "Tangerang", "Bekasi"];
  const timeSlots = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"];

  const updateFormData = (field: keyof BookingData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleServiceType = (serviceId: string) => {
    setFormData((prev) => ({
      ...prev,
      serviceType: prev.serviceType.includes(serviceId)
        ? prev.serviceType.filter((id) => id !== serviceId)
        : [...prev.serviceType, serviceId],
    }));
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return formData.motorcycleType !== "";
      case 2:
        return formData.serviceType.length > 0;
      case 3:
        return formData.problem.trim() !== "";
      case 4:
        if (formData.locationType === "home") {
          return formData.address !== "" && formData.city !== "";
        }
        return formData.locationType !== "";
      case 5:
        return formData.date !== "" && formData.time !== "";
      case 6:
        return formData.name !== "" && formData.phone !== "";
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (canProceed() && currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    console.log("Booking submitted:", formData);
    alert("Booking berhasil! Kami akan menghubungi Anda segera.");
  };

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Booking Service</h1>
          <p className="text-xl text-gray-600">Isi formulir di bawah untuk booking service</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-4">
            {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => (
              <div key={step} className="flex items-center flex-1">
                <motion.div
                  initial={false}
                  animate={{
                    scale: currentStep === step ? 1.1 : 1,
                    backgroundColor: currentStep >= step ? "#22c55e" : "#e5e7eb",
                  }}
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold relative z-10"
                >
                  {currentStep > step ? <Check className="w-5 h-5" /> : step}
                </motion.div>
                {step < totalSteps && (
                  <motion.div
                    initial={false}
                    animate={{
                      backgroundColor: currentStep > step ? "#22c55e" : "#e5e7eb",
                    }}
                    className="flex-1 h-1 mx-2"
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-gray-600">
            <span>Data Motor</span>
            <span>Jenis Service</span>
            <span>Keluhan</span>
            <span>Lokasi</span>
            <span>Jadwal</span>
            <span>Data Diri</span>
            <span>Konfirmasi</span>
          </div>
        </div>

        {/* Form Steps */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <AnimatePresence mode="wait">
            {/* Step 1: Vehicle Data */}
            {currentStep === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Data Kendaraan</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-gray-700 mb-3">Jenis Motor Listrik</label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {motorcycleTypes.map((type) => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => updateFormData("motorcycleType", type)}
                          className={`p-4 rounded-lg border-2 transition-all ${
                            formData.motorcycleType === type
                              ? "border-[#22c55e] bg-[#22c55e]/5 text-[#22c55e]"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 mb-3">Tahun Motor (Opsional)</label>
                    <input
                      type="number"
                      value={formData.motorcycleYear}
                      onChange={(e) => updateFormData("motorcycleYear", e.target.value)}
                      placeholder="Contoh: 2023"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 2: Service Type */}
            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Pilih Jenis Service</h2>
                <p className="text-gray-600 mb-6">Anda bisa memilih lebih dari satu</p>
                <div className="grid md:grid-cols-2 gap-4">
                  {serviceTypes.map((service) => (
                    <button
                      key={service.id}
                      type="button"
                      onClick={() => toggleServiceType(service.id)}
                      className={`p-6 rounded-lg border-2 transition-all text-left ${
                        formData.serviceType.includes(service.id)
                          ? "border-[#22c55e] bg-[#22c55e]/5"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-gray-900">{service.name}</h3>
                        {formData.serviceType.includes(service.id) && (
                          <Check className="w-5 h-5 text-[#22c55e]" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{service.description}</p>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Step 3: Problem Description */}
            {currentStep === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Keluhan Motor</h2>
                <textarea
                  value={formData.problem}
                  onChange={(e) => updateFormData("problem", e.target.value)}
                  placeholder="Jelaskan keluhan motor Anda, misalnya: Motor tidak bisa dinyalakan, bunyi aneh saat rem, baterai cepat habis, dll."
                  rows={8}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none resize-none"
                />
              </motion.div>
            )}

            {/* Step 4: Location */}
            {currentStep === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Lokasi Service</h2>
                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  <button
                    type="button"
                    onClick={() => updateFormData("locationType", "bengkel")}
                    className={`p-8 rounded-lg border-2 transition-all ${
                      formData.locationType === "bengkel"
                        ? "border-[#22c55e] bg-[#22c55e]/5"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <Building className="w-12 h-12 mx-auto mb-4 text-[#22c55e]" />
                    <h3 className="font-semibold text-gray-900 mb-2">Datang ke Bengkel</h3>
                    <p className="text-sm text-gray-600">Jl. Raya Kampung Baru No. 123, Jakarta</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => updateFormData("locationType", "home")}
                    className={`p-8 rounded-lg border-2 transition-all ${
                      formData.locationType === "home"
                        ? "border-[#22c55e] bg-[#22c55e]/5"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <HomeIcon className="w-12 h-12 mx-auto mb-4 text-[#22c55e]" />
                    <h3 className="font-semibold text-gray-900 mb-2">Home Service</h3>
                    <p className="text-sm text-gray-600">Kami ke lokasi Anda (Jabodetabek)</p>
                  </button>
                </div>

                {formData.locationType === "home" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="space-y-4"
                  >
                    <div>
                      <label className="block text-gray-700 mb-3">Alamat Lengkap</label>
                      <textarea
                        value={formData.address}
                        onChange={(e) => updateFormData("address", e.target.value)}
                        placeholder="Masukkan alamat lengkap Anda"
                        rows={3}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none resize-none"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 mb-3">Kota</label>
                      <select
                        value={formData.city}
                        onChange={(e) => updateFormData("city", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                      >
                        <option value="">Pilih Kota</option>
                        {cities.map((city) => (
                          <option key={city} value={city}>
                            {city}
                          </option>
                        ))}
                      </select>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {/* Step 5: Schedule */}
            {currentStep === 5 && (
              <motion.div
                key="step5"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Jadwal Booking</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-gray-700 mb-3 flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-[#22c55e]" />
                      Tanggal
                    </label>
                    <input
                      type="date"
                      value={formData.date}
                      onChange={(e) => updateFormData("date", e.target.value)}
                      min={new Date().toISOString().split("T")[0]}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 mb-3 flex items-center gap-2">
                      <Clock className="w-5 h-5 text-[#22c55e]" />
                      Waktu
                    </label>
                    <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
                      {timeSlots.map((time) => (
                        <button
                          key={time}
                          type="button"
                          onClick={() => updateFormData("time", time)}
                          className={`p-3 rounded-lg border-2 transition-all ${
                            formData.time === time
                              ? "border-[#22c55e] bg-[#22c55e]/5 text-[#22c55e]"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 6: Customer Data */}
            {currentStep === 6 && (
              <motion.div
                key="step6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Data Pelanggan</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-gray-700 mb-3">Nama Lengkap</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => updateFormData("name", e.target.value)}
                      placeholder="Masukkan nama lengkap"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 mb-3">Nomor HP (WhatsApp)</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => updateFormData("phone", e.target.value)}
                      placeholder="08xx xxxx xxxx"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 mb-3">Email (Opsional)</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                      placeholder="email@example.com"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#22c55e] focus:outline-none"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 7: Confirmation */}
            {currentStep === 7 && (
              <motion.div
                key="step7"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Konfirmasi Booking</h2>
                <div className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-4">Data Kendaraan</h3>
                    <div className="space-y-2 text-gray-700">
                      <p>Motor: <span className="font-medium">{formData.motorcycleType}</span></p>
                      {formData.motorcycleYear && (
                        <p>Tahun: <span className="font-medium">{formData.motorcycleYear}</span></p>
                      )}
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-4">Jenis Service</h3>
                    <div className="space-y-1">
                      {formData.serviceType.map((id) => {
                        const service = serviceTypes.find((s) => s.id === id);
                        return (
                          <p key={id} className="text-gray-700 flex items-center gap-2">
                            <Check className="w-4 h-4 text-[#22c55e]" />
                            {service?.name}
                          </p>
                        );
                      })}
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-4">Keluhan</h3>
                    <p className="text-gray-700">{formData.problem}</p>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-4">Lokasi Service</h3>
                    <div className="space-y-2 text-gray-700">
                      <p className="font-medium">
                        {formData.locationType === "bengkel" ? "Datang ke Bengkel" : "Home Service"}
                      </p>
                      {formData.locationType === "home" && (
                        <>
                          <p>{formData.address}</p>
                          <p>Kota: {formData.city}</p>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-4">Jadwal</h3>
                    <div className="space-y-2 text-gray-700">
                      <p>Tanggal: <span className="font-medium">{formData.date}</span></p>
                      <p>Waktu: <span className="font-medium">{formData.time}</span></p>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-4">Data Pelanggan</h3>
                    <div className="space-y-2 text-gray-700">
                      <p>Nama: <span className="font-medium">{formData.name}</span></p>
                      <p>HP: <span className="font-medium">{formData.phone}</span></p>
                      {formData.email && (
                        <p>Email: <span className="font-medium">{formData.email}</span></p>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between items-center pb-20 md:pb-0">
          <button
            type="button"
            onClick={handleBack}
            disabled={currentStep === 1}
            className="flex items-center gap-2 px-6 py-3 rounded-lg border-2 border-gray-300 text-gray-700 hover:border-gray-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-5 h-5" />
            Kembali
          </button>

          {currentStep < totalSteps ? (
            <button
              type="button"
              onClick={handleNext}
              disabled={!canProceed()}
              className="flex items-center gap-2 px-6 py-3 rounded-lg bg-[#22c55e] text-white hover:bg-[#16a34a] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Lanjut
              <ChevronRight className="w-5 h-5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              className="flex items-center gap-2 px-8 py-3 rounded-lg bg-[#22c55e] text-white hover:bg-[#16a34a] transition-colors"
            >
              <Check className="w-5 h-5" />
              Booking Sekarang
            </button>
          )}
        </div>

        {/* Mobile Sticky Navigation */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 flex gap-3">
          <button
            type="button"
            onClick={handleBack}
            disabled={currentStep === 1}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 border-gray-300 text-gray-700 hover:border-gray-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {currentStep < totalSteps ? (
            <button
              type="button"
              onClick={handleNext}
              disabled={!canProceed()}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[#22c55e] text-white hover:bg-[#16a34a] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Lanjut
              <ChevronRight className="w-5 h-5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[#22c55e] text-white hover:bg-[#16a34a] transition-colors"
            >
              <Check className="w-5 h-5" />
              Booking Sekarang
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
