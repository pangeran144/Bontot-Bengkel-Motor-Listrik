import { Link } from "react-router";
import { Zap, MapPin, Phone, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-[#22c55e] rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <span className="font-semibold text-xl">VoltService</span>
            </Link>
            <p className="text-gray-400 text-sm">
              Bengkel motor listrik profesional dengan layanan home service di Jabodetabek.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Menu</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <Link to="/" className="hover:text-[#22c55e] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/booking" className="hover:text-[#22c55e] transition-colors">
                  Booking Service
                </Link>
              </li>
              <li>
                <Link to="/spareparts" className="hover:text-[#22c55e] transition-colors">
                  Sparepart
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#22c55e] transition-colors">
                  Kontak
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Layanan</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>Servis Baterai</li>
              <li>Perbaikan Rem</li>
              <li>Cek Kelistrikan</li>
              <li>General Service</li>
              <li>Home Service</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Kontak</h3>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0 text-[#22c55e]" />
                <span>Jl. Raya Kampung Baru No. 123, Jakarta Timur</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0 text-[#22c55e]" />
                <span>+62 812-3456-7890</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 flex-shrink-0 text-[#22c55e]" />
                <span>info@voltservice.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2026 VoltService. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
