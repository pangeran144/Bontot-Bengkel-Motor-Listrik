import { Link } from "react-router";
import { useState } from "react";
import { Zap, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[#22c55e] rounded-xl flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="font-semibold text-xl text-gray-900">VoltService</span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className="text-gray-700 hover:text-[#22c55e] transition-colors">
              Home
            </Link>
            <Link to="/booking" className="text-gray-700 hover:text-[#22c55e] transition-colors">
              Booking Service
            </Link>
            <Link to="/spareparts" className="text-gray-700 hover:text-[#22c55e] transition-colors">
              Sparepart
            </Link>
            <Link to="/contact" className="text-gray-700 hover:text-[#22c55e] transition-colors">
              Kontak
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <Link
              to="/booking"
              className="hidden sm:block bg-[#22c55e] text-white px-6 py-2.5 rounded-lg hover:bg-[#16a34a] transition-colors"
            >
              Booking Sekarang
            </Link>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-700 hover:text-[#22c55e]"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-gray-100"
          >
            <div className="px-4 py-4 space-y-3">
              <Link
                to="/"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-gray-700 hover:text-[#22c55e] transition-colors"
              >
                Home
              </Link>
              <Link
                to="/booking"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-gray-700 hover:text-[#22c55e] transition-colors"
              >
                Booking Service
              </Link>
              <Link
                to="/spareparts"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-gray-700 hover:text-[#22c55e] transition-colors"
              >
                Sparepart
              </Link>
              <Link
                to="/contact"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-gray-700 hover:text-[#22c55e] transition-colors"
              >
                Kontak
              </Link>
              <Link
                to="/booking"
                onClick={() => setMobileMenuOpen(false)}
                className="block sm:hidden w-full text-center bg-[#22c55e] text-white py-3 rounded-lg hover:bg-[#16a34a] transition-colors"
              >
                Booking Sekarang
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
